class Info{
  final List<dynamic> strategies_;
  final int size_;
  Info(this.size_, this.strategies_);

  get size => size_;
  get strategies => strategies_;
}