// author: Isabella Gaytan
// CS: 3360
// Exercise: Dart - MVC 
// Controller - C

import './controller.dart';
import '../Model/info.dart';
import '../Model/board.dart';
import '../Model/webclient.dart';
import '../View/consoleui.dart';

 void main(List<String> arguments){
  Controller().start();
}

class Controller{
  void start() async{
    var ui = ConsoleUI();
    ui.showMessage('Welcome to Omok game!');

    //ui.promptServer();
    var server = ui.promptServer();
    ui.showMessage('Connecting to the server....');

    //Connect to the webclient and get information from the server
    var net = WebClient(server);

    // Get decoded map response from server
    var decodedResponse = await net.getInfo(); //returns structure that has size and strategies
    if(decodedResponse == null){
      ui.showMessage('Unable to connect.. Existing..');
      return;
    }
    
     //... prompt user to pick strategy 
    //create board
    //var board = Board(info.size); //split method into 2 or 3 methods
    List<dynamic> strategies = ['Smart', 'Random'];
    Info info = Info(decodedResponse['size'], decodedResponse['strategies']);
    var board = Board.generateBoard(info.size);
    ui.promptStrategy(strategies);
    ui.showMessage('Creating game....');
    
  }
}