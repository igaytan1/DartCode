// author: Isabella Gaytan
// CS: 3360
// Exercise: Dart - MVC 
// Board Class - M

class Board{
  final int size;
  var gameBoard;

  Board(this.size, this.gameBoard);

  static Board generateBoard(size){
    var board = List.generate(size, (i) => List.filled(size, '-', growable:false),growable:false);
    return Board(size, board);

  }

  get board => board;
}