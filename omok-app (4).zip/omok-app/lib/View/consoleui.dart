// author: Isabella Gaytan
// CS: 3360
// Exercise: Dart - MVC 
// ConsoleUI Class - V

import 'dart:io';
import '../Model/webclient.dart';

class ConsoleUI {
  void showMessage(String msg) {
    stdout.writeln(msg);
  }
  
  //bracket means optional
  promptServer([serverUrl = WebClient.defaultServer]) {
    stdout.writeln('Enter server URL or \'Enter\' for (default: $serverUrl): ');
    
    //reading one line
    var url = stdin.readLineSync();

  // if the user enter invalid url do something and then return url whether it be the default or the entered one
    if(url == null || url.isEmpty == true){
      return serverUrl;
    }
     
    return url;

  }

  // Displays strategy choices  
  promptStrategy(List<dynamic> strategies){
    stdout.writeln('Select the server strategy: ');
    for(int i = 0; i < strategies.length; i++){
      stdout.writeln('${i+1})  ${strategies[i]}');
    }

    int strategySelected = 0;

    // Checks for invalid input and handles
    while(strategySelected < 1 || strategySelected > strategies.length){
      try{
        var line = stdin.readLineSync();
        strategySelected = int.parse(line ?? '0');
        if(strategySelected < 1 || strategySelected > strategies.length){
          stdout.writeln('Invalid Selection. Try again!');
        }
      }on FormatException catch(_,e){
        stdout.writeln('Wrong Input! Please input a number between 1 - ${strategies.length}');
      }
    }
    return strategies[strategySelected-1];

  }
}