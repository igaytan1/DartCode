// author: Isabella Gaytan
// CS: 3360
// Exercise: Dart - MVC 
// WebClient Class - M

import 'package:http/http.dart' as http;
import './responseparser.dart';

class WebClient{
  static const defaultServer = 'https://www.cs.utep.edu/cheon/cs3360/project/omok/info/';
  
  var server;
  
  WebClient(this.server);
  
  getInfo() async {
    //TODO:.. method connection, json, parse and return 
    try{
      var serverUri = Uri.parse(server);
      var response = await http.get(serverUri);
      var info = ResponseParser.parseInfo(response.body);
      return info;
    }on FormatException catch(_,e){
      return null;
    }
  }
}
