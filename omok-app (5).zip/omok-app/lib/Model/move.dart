// author: Isabella Gaytan
// CS: 3360
// Exercise: Dart - MVC 
// Move Class - M

class Move{
  final int x;
  final int y;

  Move(this.x, this.y);

  
}