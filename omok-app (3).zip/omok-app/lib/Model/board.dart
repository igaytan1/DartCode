// author: Isabella Gaytan
// CS: 3360
// Exercise: Dart - MVC 
// Board Class - M


import 'dart:io';

class Board{
  final int size;
  var _coordinates;
  //List <Player> rows; 
  
  //2d list or 1d list
  //row operation to place stone, specify x and y coordinat
  //check if place is not occupied already

  //make row return player
  // rows is list of players

  Board(this.size, this._coordinates);

  static Board generateBoard(size){
    var _coordinates = List.generate(size, (i) => List.filled(size, '.', growable:false),growable:false);  
    return Board(size, _coordinates);

  }

  get coordinates => _coordinates;

  static String placeMove(var ackMove, var serverMove, coordinates, List<dynamic> pastServerMoves){
    String checkStatus = '';
    int x = ackMove['x'];
    int y = ackMove['y'];

    if(coordinates[x][y] == '.'){
      coordinates[x][y] = 'O';

      checkStatus = isWinningOrDrawMove(ackMove, serverMove, coordinates);
      if(checkStatus != 'keep playing'){
        return checkStatus;
      }

      var serverMoveX;
      var serverMoveY;

      if(serverMove['x'] == 0){
        serverMoveX = 1;
      }else{
        serverMoveX = serverMove['x']-1;
      }
      if(serverMove['y'] == 0){
        serverMoveY = 1;
      }else{
        serverMoveY = serverMove['y']-1;
      }

      updateServerMoves(pastServerMoves, coordinates);
      coordinates[serverMoveX+1][serverMoveY+1] = '*';
      pastServerMoves.add(serverMoveX);
      pastServerMoves.add(serverMoveY);
    }
    else{
      stdout.writeln('That place is taken! Try Again');
    }
    return checkStatus;
  }


  static String isWinningOrDrawMove(var ackMove, var serverMove, coordinates){
    String outcome = 'keep playing'; 

    if(ackMove['isWin'] || serverMove['isWin']){ // Check if player entered winning move 
      List<dynamic> winningRow;
      if(ackMove['isWin']){
        winningRow = ackMove['row'];
        for(int i = 1; i < winningRow.length; i= i+2){
          coordinates[winningRow[i]-1][winningRow[i-1]-1] = 'W';
        }
        outcome = 'win';
        return outcome;

      }else{
        winningRow = serverMove['row'];
        for(int i = 1; i < winningRow.length; i= i+2){
          coordinates[winningRow[i]][winningRow[i-1]] = 'L';
        }
        outcome = 'loss';
        return outcome;
      }
    } 

    if(ackMove['isDraw'] || serverMove['isDraw']){ // Check if player entered winning move 
      outcome = 'draw';
    } 
    return outcome;
  }


  static updateServerMoves(List<dynamic> pastServerMoves, coordinates){
    for(int i = 1; i < pastServerMoves.length; i= i+2){
      coordinates[pastServerMoves[i]][pastServerMoves[i-1]] = 'X';
    }
  }
}