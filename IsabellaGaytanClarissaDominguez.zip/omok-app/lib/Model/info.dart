// author: Isabella Gaytan and Clarissa Dominguez
// CS: 3360
// Exercise: Dart - MVC 
// Info Class - M

class Info{
  final List<dynamic> strategies_;
  final int size_;
  Info(this.size_, this.strategies_);

  get size => size_;
  get strategies => strategies_;
}